ALTEZZA = 720
LUNGHEZZA = 960
GRANDEZZA_TILES = 72
FPS = 60
OFFSET_Y = 100  # Offset verticale per il rendering isometrico