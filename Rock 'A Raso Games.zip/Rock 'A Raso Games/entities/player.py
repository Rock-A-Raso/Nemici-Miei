import pygame
from pygame.locals import * 

pygame.init()

TILE_WIDTH = 0
TILE_HEIGHT = 0

class Player():
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.image = pygame.image.load('')
        self.image = pygame.transform.scale(self.image, (TILE_WIDTH, TILE_HEIGHT))

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def update(self):
        pass

    def draw(self, screen):
        screen.blit(self.image, ())