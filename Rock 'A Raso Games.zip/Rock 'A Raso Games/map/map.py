import pygame

# costanti 
TILE_WIDTH = 0
TILE_HEIGHT = 0

class Game:
    def __init__(self, map_data, tileset):
        self.map_data = map_data  # matrice
        self.tileset = tileset  # immagini dei tile

    def draw(self, screen):
        #nn so come prendere tile image e da dove sono momentaneamente confuso
        screen.blit(tile_image , (TILE_WIDTH, TILE_HEIGHT))