import pygame
from pygame.locals import * 
from map.map import Map
from entities.player import Player

pygame.init()

class Game():
    def __init__(self, screen):
        self.screen = screen

        # matrice
        map_data = [

        ]

        # lista tiles
        self.tileset = []

        # caricamento di tutte le immagini

        # assegnazione dei tiles ai blocchi nella griglia

        # creazione mappa
        self.map = Map(map_data, self.tileset)

        # posizione giocatore
        self.player = Player()
    # gestione input
    def handle_events(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_w]:
            pass
        if keys[pygame.K_a]:
            pass
        if keys[pygame.K_s]:
            pass
        if keys[pygame.K_d]:
            pass

    def update(self):
        self.handle_events()
        self.player_update()
    
    # funzione per il render
    def render(self):
        self.map.draw(self.screen)
        self.player.draw(self.screen)